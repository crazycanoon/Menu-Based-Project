function navigateTo(page) {
    alert(`Navigating to ${page} page!`);  // You can replace this with actual navigation
  }
  